package com.moviesearch.controller;

import com.google.gson.Gson;
import com.moviesearch.model.LogEntry;
import com.moviesearch.model.Movie;
import com.moviesearch.model.Search;
import com.moviesearch.repository.SearchRepository;
import com.moviesearch.service.MovieService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Date;
/**
 * andrewID : qshu
 * Name: Sera Shu
 */
@WebServlet(name = "SearchController", urlPatterns = {"/search"})
public class SearchController extends HttpServlet {

    private MovieService movieService;
    private SearchRepository searchRepository;

    @Override
    public void init() throws ServletException {
        super.init();
        // Manually create instances
        this.movieService = new MovieService();
        this.searchRepository = new SearchRepository();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Constructing LogEntry to save in the repository.
        Date timestampRequestReceived = new Date();
        long startTime = System.nanoTime();

        String startYear = request.getParameter("start_year");
        String endYear = request.getParameter("end_year");
        String minImdb = request.getParameter("min_imdb");
        String maxImdb = request.getParameter("max_imdb");
        String genre = request.getParameter("genre");
        String language = request.getParameter("language");
        String type = request.getParameter("type");
        String sort = request.getParameter("sort");
        String page = request.getParameter("page");
        if(page==null || page.isEmpty()){
            page = "1";
        }
        String device = request.getParameter("device_model");

        // Constructing Search object to save in the repository.
        Search search = new Search();
        search.setStartYear(startYear);
        search.setEndYear(endYear);
        search.setMinImdb(minImdb);
        search.setMaxImdb(maxImdb);
        search.setGenre(genre);
        search.setLanguage(language);
        search.setType(type);
        search.setSort(sort);
        search.setPage(page);

        try {

            LogEntry logEntry = movieService.searchMovie(search);

            // Constructing LogEntry to save in the repository.
            logEntry.setSearch(search);
            logEntry.setMobilePhoneIdentifier(device);
            logEntry.setTimestampRequestReceived(timestampRequestReceived);

            long estimatedTime = System.nanoTime() - startTime;
            long responseTime = estimatedTime / 1000;
            logEntry.setWebResponseTime(responseTime);
            searchRepository.saveLogEntry(logEntry);

            // Convert movie to JSON and write to response
            response.setContentType("application/json");
            Movie movie = logEntry.getSearch().getMovie();
            response.getWriter().write(new Gson().toJson(movie));
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid page number.");
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred processing your search.");
        }
    }
}
