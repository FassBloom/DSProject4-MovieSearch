package com.moviesearch.controller;

import com.moviesearch.model.LogEntry;
import com.moviesearch.repository.SearchRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
/**
 * andrewID : qshu
 * Name: Sera Shu
 */
@WebServlet(name = "DashboardController", urlPatterns = {"/dashboard"})
public class DashboardController extends HttpServlet {

    private SearchRepository searchRepository;

    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize repository
        this.searchRepository = new SearchRepository();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<LogEntry> logEntries = searchRepository.findAllLogEntries();

        // Calculate Most Searched Genre
        Map<String, Long> genreFrequency = logEntries.stream()
                .collect(Collectors.groupingBy(logEntry -> logEntry.getSearch().getGenre(), Collectors.counting()));
        String mostSearchedGenre = genreFrequency.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("Not Available");

        // Calculate Average Response Time
        double averageResponseTime = logEntries.stream()
                .mapToLong(LogEntry::getApiResponseTime)
                .average()
                .orElse(0.0);

        // Determine Peak Usage Time
        Map<Integer, Long> hourFrequency = logEntries.stream()
                .collect(Collectors.groupingBy(logEntry -> logEntry.getTimestampRequestReceived().getHours(), Collectors.counting()));
        int peakUsageHour = hourFrequency.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(-1);

        request.setAttribute("mostSearchedGenre", mostSearchedGenre);
        request.setAttribute("averageResponseTime", averageResponseTime);
        request.setAttribute("peakUsageHour", peakUsageHour);
        request.setAttribute("logEntries", logEntries);

        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }
}