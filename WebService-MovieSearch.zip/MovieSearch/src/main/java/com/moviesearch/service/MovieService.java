package com.moviesearch.service;

import com.google.gson.Gson;
import com.moviesearch.model.LogEntry;
import com.moviesearch.model.Movie;
import com.moviesearch.model.MovieSearchResponse;
import com.moviesearch.model.Search;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import kong.unirest.UnirestException;
/**
 * andrewID : qshu
 * Name: Sera Shu
 * This service class is used for searching movies via an external API.
 * The class handles sending the search request, processing the response, and logging the request details.
 */
public class MovieService {

    private final String apiKey = "e5a9a52561msh9aafe12b88d6274p1ce8d3jsn5e3db4a5007e";
    private final Gson gson = new Gson();

    /**
     * Searches for movies based on the provided search criteria.
     *
     * @param search The search criteria.
     * @return A LogEntry containing details about the search request and response.
     */
    public LogEntry searchMovie(Search search) {
        LogEntry logEntry = new LogEntry();
        try {
            long startTime = System.nanoTime();
            HttpResponse<String> response = Unirest.get("https://ott-details.p.rapidapi.com/advancedsearch")
                    .queryString("start_year", search.getStartYear())
                    .queryString("end_year", search.getEndYear())
                    .queryString("min_imdb", search.getMinImdb())
                    .queryString("max_imdb", search.getMaxImdb())
                    .queryString("genre", search.getGenre())
                    .queryString("language", search.getLanguage())
                    .queryString("type", search.getType())
                    .queryString("sort", search.getSort())
                    .queryString("page", search.getPage())
                    .header("X-RapidAPI-Key", apiKey)
                    .header("X-RapidAPI-Host", "ott-details.p.rapidapi.com")
                    .asString();
            long estimatedTime = System.nanoTime() - startTime;
            long responseTime = estimatedTime / 1000;
            System.out.println("the response of make a request to the API:");
            if (response.getStatus() == 200) {
                // get times of free try of 3rd Api Remaining
                String remainingRequests = response.getHeaders().getFirst("x-ratelimit-requests-remaining");
                logEntry.setApiRemainingTimes(remainingRequests);

                MovieSearchResponse searchResponse = gson.fromJson(response.getBody(), MovieSearchResponse.class);
                System.out.println(gson.toJson(searchResponse));
                Movie movie;
                if(!searchResponse.getResults().isEmpty()) {
                    movie = searchResponse.getResults().get(0);
                    search.setMovie(movie);
                }
                logEntry.setSearch(search);
                logEntry.setApiResponseTime(responseTime);
                return logEntry;
            } else {
                // Handle non-200 status codes appropriately

                throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
            }
        } catch (UnirestException e) {
            // Handle exceptions related to the HTTP request
            throw new RuntimeException("Unirest request failed", e);
        } catch (Exception e) {
            // Handle exceptions related to parsing the response
            throw new RuntimeException("Failed to parse the API response", e);
        }
    }
}
