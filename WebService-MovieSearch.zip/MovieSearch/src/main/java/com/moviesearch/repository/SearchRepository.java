package com.moviesearch.repository;

import com.google.gson.Gson;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;
import com.moviesearch.model.LogEntry;
import com.moviesearch.model.Movie;
import com.moviesearch.model.Search;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

/**
 * andrewID : qshu
 * Name: Sera Shu
 */
public class SearchRepository {

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> logCollection;
    Gson gson = new Gson();

    public SearchRepository() {
        String connectionString = "mongodb://legolas:CMuDMirojdxnZGyg@ac-8msi8xf-shard-00-00.bq3mw8q.mongodb.net:27017,ac-8msi8xf-shard-00-01.bq3mw8q.mongodb.net:27017,ac-8msi8xf-shard-00-02.bq3mw8q.mongodb.net:27017/dslearn?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";

        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();

        try {
            mongoClient = MongoClients.create(settings);
            database = mongoClient.getDatabase("moviesearch");
            logCollection = database.getCollection("logs");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveLogEntry(LogEntry logEntry) {
        Document logEntryDoc = new Document()
                .append("timestampRequestReceived", logEntry.getTimestampRequestReceived())
                .append("mobilePhoneIdentifier", logEntry.getMobilePhoneIdentifier())
                .append("apiRemainingTimes", logEntry.getApiRemainingTimes())
                .append("apiResponseTime", logEntry.getApiResponseTime())
                .append("webResponseTime", logEntry.getWebResponseTime())
                .append("startYear", logEntry.getSearch().getStartYear())
                .append("endYear", logEntry.getSearch().getEndYear())
                .append("minImdb", logEntry.getSearch().getMinImdb())
                .append("maxImdb", logEntry.getSearch().getMaxImdb())
                .append("genre", logEntry.getSearch().getGenre())
                .append("language", logEntry.getSearch().getLanguage())
                .append("type", logEntry.getSearch().getType())
                .append("sort", logEntry.getSearch().getSort())
                .append("movie", gson.toJson(logEntry.getSearch().getMovie()));

        logCollection.insertOne(logEntryDoc);
        System.out.println("Write the document to the mongoDB database. saveLogEntry:");
        System.out.println(gson.toJson(logEntry));
    }

    public List<LogEntry> findAllLogEntries() {
        List<LogEntry> logEntries = new ArrayList<>();
        FindIterable<Document> docs = logCollection.find();
        for (Document doc : docs) {
            LogEntry logEntry = documentToLogEntry(doc);
            logEntries.add(logEntry);
        }
        System.out.println("Read all documents currently stored in the database:");
        System.out.println(gson.toJson(logEntries));
        return logEntries;
    }

    private LogEntry documentToLogEntry(Document doc) {
        LogEntry logEntry = new LogEntry();
        logEntry.setTimestampRequestReceived(doc.getDate("timestampRequestReceived"));
        logEntry.setMobilePhoneIdentifier(doc.getString("mobilePhoneIdentifier"));
        logEntry.setApiRemainingTimes(doc.getString("apiRemainingTimes"));
        logEntry.setApiResponseTime(doc.getLong("apiResponseTime"));
        logEntry.setWebResponseTime(doc.getLong("webResponseTime"));

        // Constructing Search object from Document
        Search search = new Search();
        search.setStartYear(doc.getString("startYear"));
        search.setEndYear(doc.getString("endYear"));
        search.setMinImdb(doc.getString("minImdb"));
        search.setMaxImdb(doc.getString("maxImdb"));
        search.setGenre(doc.getString("genre"));
        search.setLanguage(doc.getString("language"));
        search.setType(doc.getString("type"));
        search.setSort(doc.getString("sort"));
        search.setMovie(gson.fromJson(doc.getString("movie"), Movie.class));

        // Set the Search object to LogEntry
        logEntry.setSearch(search);

        return logEntry;
    }

    // Close the MongoDB client connection when the repository is no longer in use
    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}