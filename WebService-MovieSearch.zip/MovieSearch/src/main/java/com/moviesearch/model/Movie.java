package com.moviesearch.model;

import java.util.List;
/**
 * andrewID : qshu
 * Name: Sera Shu
 */
public class Movie {
    private String title;
    private Double imdbrating;
    private Integer released;
    private List<String> imageurl;

    // Standard getters and setters for the title field.
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Standard getters and setters for the imdbrating field.
    public Double getImdbrating() {
        return imdbrating;
    }

    public void setImdbrating(Double imdbrating) {
        this.imdbrating = imdbrating;
    }

    // Standard getters and setters for the released field.
    public Integer getReleased() {
        return released;
    }

    public void setReleased(Integer released) {
        this.released = released;
    }

    // Standard getters and setters for the imageurl field.
    public List<String> getImageurl() {
        return imageurl;
    }

    public void setImageurl(List<String> imageurl) {
        this.imageurl = imageurl;
    }
}
