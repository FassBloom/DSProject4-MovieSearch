package com.moviesearch.model;

import java.util.Date;
import java.util.List;
/**
 * andrewID : qshu
 * Name: Sera Shu
 */
public class Search {
    private String startYear;
    private String endYear;
    private String minImdb;
    private String maxImdb;
    private String genre;
    private String language;
    private String type;
    private String sort;
    private String page;
    private Movie movie;

    // Getters and setters for startYear
    public String getStartYear() {
        return startYear;
    }

    public void setStartYear(String startYear) {
        this.startYear = startYear;
    }

    // Getters and setters for endYear
    public String getEndYear() {
        return endYear;
    }

    public void setEndYear(String endYear) {
        this.endYear = endYear;
    }

    // Getters and setters for minImdb
    public String getMinImdb() {
        return minImdb;
    }

    public void setMinImdb(String minImdb) {
        this.minImdb = minImdb;
    }

    // Getters and setters for maxImdb
    public String getMaxImdb() {
        return maxImdb;
    }

    public void setMaxImdb(String maxImdb) {
        this.maxImdb = maxImdb;
    }

    // Getters and setters for genre
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    // Getters and setters for language
    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    // Getters and setters for type
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    // Getters and setters for sort
    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    // Getters and setters for page
    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    // Getters and setters for the list of movies
    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }
}
