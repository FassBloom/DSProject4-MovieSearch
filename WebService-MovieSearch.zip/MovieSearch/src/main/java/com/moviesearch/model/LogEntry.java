package com.moviesearch.model;

import java.util.Date;
/**
 * andrewID : qshu
 * Name: Sera Shu
 */
public class LogEntry {
    private Date timestampRequestReceived; // time of this web service received
    private String mobilePhoneIdentifier; // mobile model
    private long apiResponseTime; // 3rd api in microseconds
    private long webResponseTime; // this web service in microseconds
    private String apiRemainingTimes; // free try of 3rd Api Remaining
    private Search search;

    // Getter and Setter methods for timestampRequestReceived
    public Date getTimestampRequestReceived() {
        return timestampRequestReceived;
    }

    public void setTimestampRequestReceived(Date timestampRequestReceived) {
        this.timestampRequestReceived = timestampRequestReceived;
    }

    // Getter and Setter methods for mobilePhoneIdentifier
    public String getMobilePhoneIdentifier() {
        return mobilePhoneIdentifier;
    }

    public void setMobilePhoneIdentifier(String mobilePhoneIdentifier) {
        this.mobilePhoneIdentifier = mobilePhoneIdentifier;
    }

    // Getter and Setter methods for apiResponseTime
    public long getApiResponseTime() {
        return apiResponseTime;
    }

    public void setApiResponseTime(long apiResponseTime) {
        this.apiResponseTime = apiResponseTime;
    }

    // Getter and Setter methods for webResponseTime
    public long getWebResponseTime() {
        return webResponseTime;
    }

    public void setWebResponseTime(long webResponseTime) {
        this.webResponseTime = webResponseTime;
    }

    // Getter and Setter methods for apiRemainingTimes
    public String getApiRemainingTimes() {
        return apiRemainingTimes;
    }

    public void setApiRemainingTimes(String apiRemainingTimes) {
        this.apiRemainingTimes = apiRemainingTimes;
    }

    // Getter and Setter methods for search
    public Search getSearch() {
        return search;
    }

    public void setSearch(Search search) {
        this.search = search;
    }
}

